package hn.lenguajes.examen.controladores;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import hn.lenguajes.examen.modelos.Vehiculos;
import hn.lenguajes.examen.services.impl.VehiculoServiceImp;

@RestController
@RequestMapping("/api/vehiculos")
public class VehiculosController {
    @Autowired
    public VehiculoServiceImp vehiculoServiceImp;

    @PostMapping("crear")
    public Vehiculos crearVehiculo(@RequestBody Vehiculos nvoVehiculo) {
        return this.vehiculoServiceImp.crearVehiculo(nvoVehiculo);
    }

    @GetMapping("/obtener/todos")
    public List<Vehiculos> obtenerVehiculos() {
        return this.vehiculoServiceImp.cargarVehiculos();
    }

    @GetMapping("/obtener/vehciculo")
    public Vehiculos cargarVehiculo(@RequestParam int idVehiculo) {
        return this.vehiculoServiceImp.cargarVehiculoID(idVehiculo);
    }
}
