package hn.lenguajes.examen.services;

import java.util.List;

import hn.lenguajes.examen.modelos.Cliente;
import hn.lenguajes.examen.modelos.TipoCliente;

public interface ClienteService {
    public Cliente crearCliente(Cliente nvoCliente);

    public List<Cliente> obtenerTodosClientes();

    public Cliente obtenerCliente(int clienteId);

    public TipoCliente craerTipoCliente(TipoCliente nvoTipoCliente);
}
