package hn.lenguajes.examen.modelos;

public class TipoVehiculo {

    @Id
    @OneToMany(mappedBy = "vehiculos", cascade = CascadeType.ALL)
    private int idTipoVehiculo;

    private String descripcion;

    private Double precioXHora;

}
