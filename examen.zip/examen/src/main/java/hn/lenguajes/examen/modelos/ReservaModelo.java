package hn.lenguajes.examen.modelos;

import java.text.DecimalFormat;
import java.util.Date;

import jakarta.persistence.Id;
import jakarta.persistence.Column;

public class ReservaModelo {
    @Id
    private Integer id;

    private Integer idCliente;

    private Integer idVehiculo;

    @Column(name = "fecha")
    private Date fecha;

    private Integer dias;

    private DecimalFormat total;

    @OneToOne
    @JoinColumn(name = "idCliente", ReferenceColumn = "codigoCliente")

    private Cliente cliente;

}
