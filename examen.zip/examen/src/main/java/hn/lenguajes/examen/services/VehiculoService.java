package hn.lenguajes.examen.services;

import java.util.List;

import hn.lenguajes.examen.modelos.Vehiculos;

public interface VehiculoServive {

    public Vehiculos nvoVehiculos(Vehiculos nvoVehiculos);

    public Vehiculos obtenerVehiculo();

    public List<Vehiculos> obtenerVehiculos();
}
