package hn.lenguajes.examen.repositorios;

import org.springframework.jpa.repository.JpaRepository;

import hn.lenguajes.examen.modelos.Vehiculos;

public interface VehiculosRepository extends JpaRepository<Vehiculos, String> {
}
