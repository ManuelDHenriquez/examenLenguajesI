package hn.lenguajes.examen.services.impl;

import java.util.List;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hn.lenguajes.examen.modelos.Cliente;
import hn.lenguajes.examen.modelos.TipoCliente;
import hn.lenguajes.examen.repositorios.ClientesRepository;
import hn.lenguajes.examen.services.ClienteService;

@Service
public class ClienteServiceImp implements ClienteService {
    @Autowired
    private ClientesRepository clientesRepository;

    @Override
    public Cliente creaCliente(Cliente nvocliente) {
        return clientesRepository.save(nvocliente);
    }

    @Override
    public List<Cliente> obtenerTodos() {
        return this.clientesRepository.findAll();
    }

    @Override
    public Cliente obtenerCienteId(int codigoCliente) {
        return this.clientesRepository.findById(codigoCliente);
    }

    @Override
    public TipoCliente crearTipoCliente(TipoCliente nvoTipoCliente) {
        return this.clientesRepository.crearTipoCliente(nvoTipoCliente);
    }
}
