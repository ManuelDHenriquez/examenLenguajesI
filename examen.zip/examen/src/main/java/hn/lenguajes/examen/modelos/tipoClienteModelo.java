package hn.lenguajes.examen.modelos;

import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

import org.springframework.stereotype.Indexed;

public class TipoCliente {

    @Id
    @OneToMany(mappedBy = "idTipCliente", cascade = CascadeType.ALL)
    private int idTipoCliente;

    private String descripcion;

}
