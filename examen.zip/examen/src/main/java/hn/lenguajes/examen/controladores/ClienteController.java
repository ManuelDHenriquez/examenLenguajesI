package hn.lenguajes.examen.controladores;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import hn.lenguajes.examen.modelos.Cliente;
import hn.lenguajes.examen.modelos.TipoCliente;
import hn.lenguajes.examen.services.ClienteService;

@RestController
@RequestMapping("/api/clientes")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @PostMapping("crear")
    public Cliente creaCliente(@RequestBody nvoCliente) {
        if (nvoCliente == null) {
            return "No hay cliente";
        }
        return this.clienteService.crearCliente(nvoCliente);
    }

    @GetMapping("/obtener/todos")
    public List<Cliente> obtenerTodos() {
        return this.clienteService.obtenerTodosClientes();
    }

    @GetMapping("/obtener")
    public Cliente ObtenerClienteId(@RequestParam(name = "codigoCliente") int codigoCliente) {
        return this.clienteService.obtenerCliente(codigoCliente);
    }

    @PostMapping("/tipoCliente")
    public TipoCliente crearTipoCliente(@RequestBody TipoCliente tipoCliente) {
        return this.clienteService.save(tipoCliente);
    }
}
