package hn.lenguajes.examen.repositorios;

import org.springframework.jpa.repository.JpaRepository;

import hn.lenguajes.examen.modelos.ReservaModelo;

public interface ReservaRepository extends JpaRepository<ReservaModelo, String> {

}
