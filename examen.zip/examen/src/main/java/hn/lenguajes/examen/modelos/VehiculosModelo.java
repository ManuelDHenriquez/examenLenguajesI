package hn.lenguajes.examen.modelos;

import jakarta.persistence.Id;

public class Vehiculos {
    @Id
    private int idVehiculo;

    private String marca;

    private int anio;

    private Boolean disponible;

    @ManyToOne
    @JoinColumn(name = "idTipoVehiculo", referenceColumnName = "idTipoVehiculo")
    private int idTipoVehiculo;
}
