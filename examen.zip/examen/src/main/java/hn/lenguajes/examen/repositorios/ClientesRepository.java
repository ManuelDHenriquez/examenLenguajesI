package hn.lenguajes.examen.repositorios;

import org.springframework.jpa.repository.JpaRepository;

import hn.lenguajes.examen.modelos.Cliente;

public interface ClientesRepository extends JpaRepository<Cliente, String> {
}
