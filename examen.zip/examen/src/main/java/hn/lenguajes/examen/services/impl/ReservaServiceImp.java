package hn.lenguajes.examen.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.web.bind.annotation.RequestBody;

import hn.lenguajes.examen.modelos.ReservaModelo;
import hn.lenguajes.examen.modelos.TipoVehiculo;
import hn.lenguajes.examen.modelos.Vehiculos;
import hn.lenguajes.examen.services.ReservaService;

public class ReservaServiceImp implements ReservaService {

    @Autowired
    public ReservaService reservaService;

    @Override
    public ReservaModelo crearReserva(ReservaModelo nvoReserva, Vehiculos vehiculo) {

        if (vehiculo.disponible == false) {
            return "Este vehículo ya se encuentra rentado";
        }
        var tipoVehiculo = obtenerTipoVehiculo(vehiculo.idTipoVehiculo);

        var precioVehiculo = tipoVehiculo.precioXhora * vehiculo.dias * 24;

        nvoReserva.total = precioVehiculo;
        
        return this.reservaService.save(nvoReserva);
    }

    @Override
    public TipoVehiculo obtenerTipoVehiculo(TipoVehiculo tipoVehiculo) {
        return this.TipoVehiculo.findById(tipoVehiculo);
    }
}
