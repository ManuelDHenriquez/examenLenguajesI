package hn.lenguajes.examen.services.impl;

import java.util.List;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import hn.lenguajes.examen.modelos.Vehiculos;
import hn.lenguajes.examen.services.VehiculoService;

@Service
public class VehiculoServiceImp implements VehiculoService {

    @Autowired
    public VehiculoService Vehiculos;

    public Vehiculos crearVehiculo(Vehiculos nvoVehiculo) {
        return this.Vehiculos.save(nvoVehiculo);
    }

    @Override
    public List<Vehiculos> cargarVehiculos() {
        return this.Vehiculos.findAll();
    }

    @Override
    public Vehiculo cargarVehiculoID(@RequestParam int idVehiculo) {
        if (idVehiculo == 0 || idVehiculo <= 0) {
            return "Vehiculo no encontrado";
        }
        return this.Vehiculos.findById(idVehiculo);
    }
}
