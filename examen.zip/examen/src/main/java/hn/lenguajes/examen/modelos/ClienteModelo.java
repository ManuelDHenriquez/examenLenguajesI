package hn.lenguajes.examen.modelos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Id;
import jakarta.persistence.Column;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity 
@Table(name="cliente");
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class Cliente {
    @Id
    private String codigoCliente;
    
    private String nombre;

    private String apellido;
    
    @Column(name="fechaIngreso")
    private Date fechaIngreso;
    
    @OneToMany(mappedBy="cliente", cascade = CascadeType.ALL)
    private TipoCliente idTipoCliente;
    
}