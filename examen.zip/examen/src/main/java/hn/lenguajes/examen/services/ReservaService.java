package hn.lenguajes.examen.services;

import java.util.List;

import hn.lenguajes.examen.modelos.ReservaModelo;

public interface ReservaRepository {
    public ReservaModelo crearReserva(ReservaModelo nvaReserva);

    public List<ReservaModelo> ObtenerReservas();
}
