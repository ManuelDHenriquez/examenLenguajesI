package hn.lenguajes.examen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenApplicationTests {

	@Test
	void contextLoads() {
	}

}
